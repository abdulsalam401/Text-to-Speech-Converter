import tkinter as tk
from tkinter import ttk
import pyttsx3

def action():
    
    sentence=txt.get("1.0","end-1c")
    engine.say(sentence)
    engine.runAndWait()


    engine.setProperty('rate',tmp.get())
    engine.setProperty('volume',volm.get())

    sel_voice=vc.get()
    voices=engine.getProperty('voices')
    if (sel_voice=='male'):
        engine.setProperty('voice',voices[0].id)
    elif (sel_voice=='female'):
        engine.setProperty('voice',voices[1].id)    


engine=pyttsx3.init()



root=tk.Tk()
root.geometry("600x300")
root.title("Text To Speech Convertor: By Abdul Salam ")


lbl=tk.Label(root,text="Enter Text:",font=("calibri",15))
lbl.place(x=30,y=20)

lbl2=tk.Label(root,text="volume",font=("calibri",15))
lbl2.place(x=270,y=150)

lbl3=tk.Label(root,text="Tempo",font=("calibri",15))
lbl3.place(x=400,y=150)

lbl4=tk.Label(root,text="Select Voices",font=("calibri",15))
lbl4.place(x=100,y=150)

volm=tk.DoubleVar(value=1.0)
vol=tk.Scale(root,from_=0,to=1,resolution=0.1,orient="horizontal",variable=volm)
vol.place(x=270,y=180)

tmp=tk.IntVar(value=150)
tempo=tk.Scale(root,from_=1,to=300,orient="horizontal",variable=tmp)
tempo.place(x=400,y=180)

vc=ttk.Combobox(root,values=['male','female'])

vc.place(x=100,y=200)


txt=tk.Text(root,height=6, width=40)
txt.place(x=150,y=20)

btn=ttk.Button(root,text="Convert", command=action)
btn.place(x=270,y=250)


root.mainloop()






root.mainloop()