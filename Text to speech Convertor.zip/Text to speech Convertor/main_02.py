import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pyttsx3
import threading

# Initialize engine globally
engine = pyttsx3.init()


def get_voice_by_gender(gender):
    voices = engine.getProperty('voices')
    gender = gender.lower()
    for v in voices:
        # Check if gender attribute exists and is not None
        if hasattr(v, 'gender') and v.gender and gender in v.gender.lower():
            return v.id
        # Fallback: check gender in voice name
        if gender in v.name.lower():
            return v.id
    # Fallback: return the first available voice
    return voices[0].id


def update_labels(*args):
    lbl_vol_val.config(text=f"{volm.get():.1f}")
    lbl_rate_val.config(text=f"{tmp.get()}")

def action():
    sentence = txt.get("1.0", "end-1c").strip()
    if not sentence:
        messagebox.showerror("Input Error", "Please enter some text.")
        return
    sel_voice = vc.get()
    if not sel_voice:
        messagebox.showerror("Voice Error", "Please select a voice.")
        return

    # Set properties before speaking
    engine.setProperty('rate', tmp.get())
    engine.setProperty('volume', volm.get())
    voice_id = get_voice_by_gender(sel_voice)
    engine.setProperty('voice', voice_id)

    # Speak in a separate thread to avoid UI freezing
    threading.Thread(target=lambda: [engine.say(sentence), engine.runAndWait()]).start()

def save_audio():
    sentence = txt.get("1.0", "end-1c").strip()
    if not sentence:
        messagebox.showerror("Input Error", "Please enter some text.")
        return
    file_path = filedialog.asksaveasfilename(defaultextension=".wav", filetypes=[("WAV files", "*.wav")])
    if not file_path:
        return
    sel_voice = vc.get()
    engine.setProperty('rate', tmp.get())
    engine.setProperty('volume', volm.get())
    voice_id = get_voice_by_gender(sel_voice)
    engine.setProperty('voice', voice_id)
    engine.save_to_file(sentence, file_path)
    engine.runAndWait()
    messagebox.showinfo("Saved", f"Audio saved as {file_path}")

def stop_speech():
    engine.stop()

def toggle_theme():
    if style.theme_use() == "clam":
        style.theme_use("alt")
        root.configure(bg="#222")
        for widget in root.winfo_children():
            widget.configure(bg="#222", fg="#eee")
    else:
        style.theme_use("clam")
        root.configure(bg="#f0f0f0")
        for widget in root.winfo_children():
            widget.configure(bg="#f0f0f0", fg="#222")

# --- UI Setup ---
root = tk.Tk()
root.geometry("650x350")
root.title("Text To Speech Converter: By Abdul Salam")

style = ttk.Style(root)
style.theme_use("clam")

# --- Layout Functions ---
def build_ui():
    # Text input
    tk.Label(root, text="Enter Text:", font=("Calibri", 15)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
    global txt
    txt = tk.Text(root, height=6, width=50, font=("Calibri", 12))
    txt.grid(row=0, column=1, columnspan=3, padx=10, pady=10)

    # Voice selection
    tk.Label(root, text="Select Voice:", font=("Calibri", 13)).grid(row=1, column=0, padx=10, pady=5, sticky="w")
    global vc
    vc = ttk.Combobox(root, values=["male", "female"], font=("Calibri", 12), state="readonly", width=10)
    vc.grid(row=1, column=1, padx=10, pady=5, sticky="w")
    vc.set("male")

    # Volume
    tk.Label(root, text="Volume:", font=("Calibri", 13)).grid(row=2, column=0, padx=10, pady=5, sticky="w")
    global volm, lbl_vol_val
    volm = tk.DoubleVar(value=1.0)
    vol = tk.Scale(root, from_=0, to=1, resolution=0.1, orient="horizontal", variable=volm, command=update_labels)
    vol.grid(row=2, column=1, padx=10, pady=5, sticky="w")
    lbl_vol_val = tk.Label(root, text="1.0", font=("Calibri", 12))
    lbl_vol_val.grid(row=2, column=2, padx=5, sticky="w")

    # Rate (Tempo)
    tk.Label(root, text="Rate:", font=("Calibri", 13)).grid(row=3, column=0, padx=10, pady=5, sticky="w")
    global tmp, lbl_rate_val
    tmp = tk.IntVar(value=150)
    tempo = tk.Scale(root, from_=50, to=300, orient="horizontal", variable=tmp, command=update_labels)
    tempo.grid(row=3, column=1, padx=10, pady=5, sticky="w")
    lbl_rate_val = tk.Label(root, text="150", font=("Calibri", 12))
    lbl_rate_val.grid(row=3, column=2, padx=5, sticky="w")

    # Buttons
    ttk.Button(root, text="Convert", command=action).grid(row=4, column=1, pady=15, sticky="ew")
    ttk.Button(root, text="Save as WAV", command=save_audio).grid(row=4, column=2, pady=15, sticky="ew")
    ttk.Button(root, text="Stop", command=stop_speech).grid(row=4, column=3, pady=15, sticky="ew")
    ttk.Button(root, text="Dark Mode", command=toggle_theme).grid(row=4, column=0, pady=15, sticky="ew")

build_ui()
update_labels()

root.mainloop()
