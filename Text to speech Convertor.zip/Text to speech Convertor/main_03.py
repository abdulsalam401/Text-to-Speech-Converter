import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pyttsx3
import threading
import os # Added for file handling
from pydub import AudioSegment # Added for MP3 conversion
import time # Added for unique temp filename

# Initialize engine globally
engine = pyttsx3.init()


def get_voice_by_gender(gender):
    voices = engine.getProperty('voices')
    gender = gender.lower()
    for v in voices:
        # Check if gender attribute exists and is not None (less reliable in pyttsx3)
        # Fallback: check gender in voice name
        if gender in v.name.lower():
            return v.id
    # Fallback: return the first available voice
    return voices[0].id


def update_labels(*args):
    """Updates the volume and rate display labels."""
    lbl_vol_val.config(text=f"{volm.get():.1f}")
    lbl_rate_val.config(text=f"{tmp.get()}")

def action():
    """Converts the text to speech and plays it."""
    sentence = txt.get("1.0", "end-1c").strip()
    if not sentence:
        messagebox.showerror("Input Error", "Please enter some text.")
        return
    sel_voice = vc.get()
    if not sel_voice:
        messagebox.showerror("Voice Error", "Please select a voice.")
        return

    # Set properties before speaking
    engine.setProperty('rate', tmp.get())
    engine.setProperty('volume', volm.get())
    voice_id = get_voice_by_gender(sel_voice)
    engine.setProperty('voice', voice_id)

    # Speak in a separate thread to avoid UI freezing
    threading.Thread(target=lambda: [engine.say(sentence), engine.runAndWait()]).start()

def save_audio():
    """Saves the converted speech as a WAV or MP3 file."""
    sentence = txt.get("1.0", "end-1c").strip()
    if not sentence:
        messagebox.showerror("Input Error", "Please enter some text.")
        return

    # Updated file dialog to include MP3
    file_path = filedialog.asksaveasfilename(
        defaultextension=".wav",
        filetypes=[("WAV files", "*.wav"), ("MP3 files", "*.mp3")]
    )
    if not file_path:
        return

    # Determine the desired output format
    file_extension = os.path.splitext(file_path)[1].lower()
    
    sel_voice = vc.get()
    engine.setProperty('rate', tmp.get())
    engine.setProperty('volume', volm.get())
    voice_id = get_voice_by_gender(sel_voice)
    engine.setProperty('voice', voice_id)

    if file_extension == ".wav":
        # Save directly as WAV using pyttsx3
        engine.save_to_file(sentence, file_path)
        engine.runAndWait()
        messagebox.showinfo("Saved", f"Audio saved successfully as {file_path}")
    
    elif file_extension == ".mp3":
        # --- MP3 Conversion Logic ---
        # 1. Save to a temporary WAV file first
        temp_wav_path = f"temp_tts_{int(time.time())}.wav"
        
        try:
            engine.save_to_file(sentence, temp_wav_path)
            engine.runAndWait()
            
            # 2. Convert WAV to MP3 using pydub
            audio = AudioSegment.from_wav(temp_wav_path)
            audio.export(file_path, format="mp3")
            
            messagebox.showinfo("Saved", f"Audio saved successfully as {file_path}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save as MP3. Ensure 'pydub' and 'ffmpeg' are installed and configured. Error: {e}")
            
        finally:
            # 3. Clean up the temporary WAV file
            if os.path.exists(temp_wav_path):
                os.remove(temp_wav_path)

def stop_speech():
    """Stops the currently playing speech."""
    engine.stop()

def toggle_theme():
    """Toggles between 'clam' (light) and 'alt' (dark) themes."""
    # A complete theme switch requires configuring individual ttk widgets
    # which is complex. For simplicity, we just switch the window/widget
    # backgrounds and text colors.
    if root.tk.call('ttk::style', 'theme', 'use') == "clam":
        root.tk.call('ttk::style', 'theme', 'use', 'alt')
        root.configure(bg="#222")
        fg_color = "#eee"
        bg_color = "#222"
    else:
        root.tk.call('ttk::style', 'theme', 'use', 'clam')
        root.configure(bg="#f0f0f0")
        fg_color = "#222"
        bg_color = "#f0f0f0"
    
    # Apply colors to standard tk widgets
    for widget in root.winfo_children():
        if isinstance(widget, (tk.Label, tk.Scale, tk.Text)):
            try:
                widget.config(bg=bg_color, fg=fg_color)
            except tk.TclError:
                pass # Ignore widgets that don't support bg/fg

# --- UI Setup ---
root = tk.Tk()
root.geometry("650x350")
# Personalizing the title based on your profile
root.title("Text To Speech Converter: By Abdul Salam") 

# Set initial theme
style = ttk.Style(root)
style.theme_use("clam")

# --- Layout Functions ---
def build_ui():
    """Builds the main graphical user interface elements."""
    # Text input
    tk.Label(root, text="Enter Text:", font=("Calibri", 15)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
    global txt
    txt = tk.Text(root, height=6, width=50, font=("Calibri", 12))
    txt.grid(row=0, column=1, columnspan=3, padx=10, pady=10)

    # Voice selection
    tk.Label(root, text="Select Voice:", font=("Calibri", 13)).grid(row=1, column=0, padx=10, pady=5, sticky="w")
    global vc
    vc = ttk.Combobox(root, values=["male", "female"], font=("Calibri", 12), state="readonly", width=10)
    vc.grid(row=1, column=1, padx=10, pady=5, sticky="w")
    vc.set("male")

    # Volume
    tk.Label(root, text="Volume:", font=("Calibri", 13)).grid(row=2, column=0, padx=10, pady=5, sticky="w")
    global volm, lbl_vol_val
    volm = tk.DoubleVar(value=1.0)
    vol = tk.Scale(root, from_=0, to=1, resolution=0.1, orient="horizontal", variable=volm, command=update_labels)
    vol.grid(row=2, column=1, padx=10, pady=5, sticky="w")
    lbl_vol_val = tk.Label(root, text="1.0", font=("Calibri", 12))
    lbl_vol_val.grid(row=2, column=2, padx=5, sticky="w")

    # Rate (Tempo)
    tk.Label(root, text="Rate:", font=("Calibri", 13)).grid(row=3, column=0, padx=10, pady=5, sticky="w")
    global tmp, lbl_rate_val
    tmp = tk.IntVar(value=150)
    tempo = tk.Scale(root, from_=50, to=300, orient="horizontal", variable=tmp, command=update_labels)
    tempo.grid(row=3, column=1, padx=10, pady=5, sticky="w")
    lbl_rate_val = tk.Label(root, text="150", font=("Calibri", 12))
    lbl_rate_val.grid(row=3, column=2, padx=5, sticky="w")

    # Buttons
    ttk.Button(root, text="Convert", command=action).grid(row=4, column=1, pady=15, sticky="ew")
    # Button text changed to reflect both WAV/MP3 capability
    ttk.Button(root, text="Save Audio", command=save_audio).grid(row=4, column=2, pady=15, sticky="ew")
    ttk.Button(root, text="Stop", command=stop_speech).grid(row=4, column=3, pady=15, sticky="ew")
    ttk.Button(root, text="Dark Mode", command=toggle_theme).grid(row=4, column=0, pady=15, sticky="ew")

build_ui()
update_labels() # Initial call to set label values

root.mainloop()